import spark.implicits._
//the function find all the dates having too big number of connection (> 20000)
val path = "access.log.gz"

def spark = read

val logs = spark.read.text(path)
//Convert the data to

{

  case class AccessLog(
                        ip: String,
                        ident: String,
                        user: String,
                        datetime: String,
                        request: String,
                        status: String,
                        size: String,
                        referer: String,
                        userAgent: String,
                        unk: String)

  val R = """^(?<ip>[0-9.]+) (?<identd>[^ ]) (?<user>[^ ]) \[(?<datetime>[^\]]+)\] \"(?<request>[^\"]*)\" (?<status>[^ ]*) (?<size>[^ ]*) \"(?<referer>[^\"]*)\" \"(?<useragent>[^\"]*)\" \"(?<unk>[^\"]*)\"""".r

  def toAccessLog(params: List[String]) = AccessLog(
    params(0),
    params(1),
    params(2),
    params(3),
    params(4),
    params(5),
    params(6),
    params(7),
    params(8),
    params(9)
  )
}
dsExtended.cache
dsExtended.createOrReplaceTempView("AccessLogExt") {
  //the function find all the dates having too big number of connection (> 20000)
  val sql =
    """select count(*) as count, cast(datetime as date) as date
 from AccessLogExt
  group by date
  HAVING count(*) > 20000
  order by count desc"""

  def findDatesHavingMoreThan20kConnections: Seq[java.sql.Date] =
    spark.sql(sql).select("date").map(_.getDate(0)).collect()

  val theDates = findDatesHavingMoreThan20kConnections
  val currentDate = theDates(0)

  {
    //compute the list of number of access by URI for each URI

    def numberOfAccessByUri(currentDate: java.sql.Date) = spark
      .sql("select uri, cast(datetime as date) as date, count(*) as countaccess from AccessLogExt group by date, uri order by countaccess desc")
      .filter(col("date") === currentDate).drop("date")

    case class UriReport(access: Map[String, Long])
  }
    // compute the list of number of access per IP address for each IP address

    def reportByDate(currentDate: java.sql.Date) = UriReport(
      numberOfAccessByUri(currentDate)
        .collect.map(r => (r.getString(0), r.getLong(1))).toMap
    )

   {
     //Write reports as json
     val reportAsSeq = theDates.map(date => (date,reportByDate(date)))
     reportAsSeq.toDF("date", "uriReport")
       .coalesce(1)
       .write
       .mode("Overwrite")
       .json("myjsonreport")
  }

}

}}