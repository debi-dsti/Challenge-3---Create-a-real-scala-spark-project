import java.sql.Date

def convertToDataFrame(csvData: String): DataFrame = {
  val headers :: rows = csvData.split("\n").toList
  val normalizedHeaders = normalizeHeaders(headers)
  rows.map(_.split(",")).map(toTuple9).toDF(normalizedHeaders:_*)
}
println("Station, Station_name, Elivation, Latitute, Longitute, Date, Hpcp, MeasurementFlag, QualityFlag")
val bufferedSource = io.Source.fromFile("/tmp/PRECIP_HLY_sample_csv.csv")
for (line <- bufferedSource.getLines) {
  val cols = line.split(",").map(_.trim)
  // do whatever you want with the columns here
  println("${cols(0)}|${cols(1)}|${cols(2)}|${cols(3)}|${cols(4)}|${cols(5)}|${cols(6)}|${cols(7)}|${cols(8)}")
}
bufferedSource.close

}
for (line <- bufferedSource.getLines) {
  val Array(Station, Station_name, Elivation, Latitute, Longitute, Date, Hpcp, MeasurementFlag, QualityFlag) = line.split(",").map(_.trim)
  println("$Station $Station_name $Elivation $Latitute $Longitute $Date $Hpcp $MeasurementFlag $QualityFlag")
}